# fis-gaia-dr3-full-20260627-b4db1f05-3e64bfe97038

Local archival package for the completed Found in Space Gaia DR3 full download.

This package supersedes the earlier local dirty-provenance package `fis-gaia-dr3-full-20260627-b4db1f05-0a2780b72e96`.

## Contents

- `config/project.toml` - resolved pipeline run configuration.
- `config/pyproject.toml` and `config/uv.lock` - dependency context.
- `payload/gaia-votables/` - raw Gaia VOTable gzip files as hardlinks to the local download cache.
- `evidence/gaia-download.sqlite` - downloader state database.
- `evidence/gaia-download-queries/` - generated ADQL count/download query bundle.
- `evidence/gaia-download-state-summary.json` - exported state summary.
- `evidence/gaia-download-batches.json` - exported per-batch state.
- `manifests/` - file manifests and checksum outputs.
- `provenance/` - git commit and clean tracked-worktree status.

## Key Facts

- Pipeline git HEAD: `3e64bfe97038b4f62395601a2ccc6bca7ad44556`
- Tracked source worktree clean: `true`
- Acquisition spec hash: `b4db1f05d67e4deb38a91c9547ea7a38c33b93ad26c9d0cd326ad198efcebd47`
- Count query hash: `dcda88ac871bcd121f915e77e8fa887def220fd7ed4c0e95708df61d6b6d57ee`
- Download query hash: `74b3d22969b65fa910adc6ce628b08135fd41fd4d1b2383ded7facba639fbb40`
- Raw VOTable files: `60`
- Raw VOTable bytes: `146842060166`
- Source rows from count table: `1467744818`
- Raw payload SHA256 manifest: `manifests/gaia-votables.sha256`

## Handling Notes

The payload files are hardlinks, not independent copies. This keeps local disk usage low while making the package tree usable as an upload source. Treat the package as immutable and do not edit files in place.

Credentials and local shell environment files are intentionally excluded. The local run `project.toml` is intentionally archived under `config/project.toml`.
